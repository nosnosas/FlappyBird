package com.example.flappybird;

import static org.junit.jupiter.api.Assertions.*;

class AplikacijaTest {
public void test()
{
    Aplikacija test = new Aplikacija();

}
}