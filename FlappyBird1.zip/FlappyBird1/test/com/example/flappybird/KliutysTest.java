package com.example.flappybird;

import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KliutysTest {

    @Test
    void getObj() {
        AnchorPane kliutis = new AnchorPane();
        kliutis.prefWidth(600);
        kliutis.prefHeight(400);
        double kliutiesAukstis = 600;
        double kliutiesPlotis = 400;

        Kliutys obj1 = Kliutys.getObj(kliutis, kliutiesAukstis, kliutiesPlotis);
        Kliutys obj2 = Kliutys.getObj(kliutis, kliutiesAukstis, kliutiesPlotis);

        assertEquals(obj1, obj2);
    }

    @Test
    void judintiStaciakampi() {
        Rectangle rectangle = new Rectangle(37, 37);

        assertEquals(-0.75, rectangle.getX()-0.75);
    }
}