package com.example.flappybird;

import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PaukstisTest {

    @Test
    void getObj() {
        Rectangle paukstis = new Rectangle(37, 37);
        int suolioAukstis = 50;

        Paukstis obj1 = Paukstis.getObj(paukstis, suolioAukstis);
        Paukstis obj2 = Paukstis.getObj(paukstis, suolioAukstis);

        assertEquals(obj1, obj2);
    }
}