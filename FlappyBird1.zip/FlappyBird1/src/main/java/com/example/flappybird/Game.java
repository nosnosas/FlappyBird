package com.example.flappybird;

// Template Pattern
public abstract class Game {
    abstract void start();
    abstract void end();
}
