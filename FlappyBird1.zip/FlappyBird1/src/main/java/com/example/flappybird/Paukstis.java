package com.example.flappybird;

import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;

// Inheritance
public class Paukstis extends Susidurimas {

    // creational design pattern - singleton
    private static Paukstis obj;
    private Rectangle paukstis;
    private int suolioAukstis;

    private Paukstis(Rectangle paukstis, int suolioAukstis) {
        this.paukstis = paukstis;
        this.suolioAukstis = suolioAukstis;
    }

    public static Paukstis getObj(Rectangle paukstis, int suolioAukstis){
        if (obj == null){
            synchronized(Paukstis.class){
                if (obj == null){
                    obj = new Paukstis(paukstis, suolioAukstis);//instance will be created at request time
                }
            }
        }
        return obj;
    }

    public void skridimas(){
        double judejimas = -suolioAukstis;
        if(paukstis.getLayoutY() + paukstis.getY() <= suolioAukstis){
            judejimas = -(paukstis.getLayoutY() + paukstis.getY());
        }

        judintiPaukstiY(judejimas);
    }
    public void judintiPaukstiY(double positionChange){
        paukstis.setY(paukstis.getY() + positionChange);
    }

    public boolean arPaukstisGyvas(ArrayList<Rectangle> kliutys, AnchorPane kliutis){
        double paukstisY = paukstis.getLayoutY() + paukstis.getY();

        if(susidurimoAtpazinimas(kliutys, paukstis)){
            return  true;
        }

        return paukstisY >= kliutis.getHeight();
    }
}
